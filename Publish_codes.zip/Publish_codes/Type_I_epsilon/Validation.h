#ifndef VALIDATION_H
#define VALIDATION_H

#include "init_KAQ.h"

bool validate_best(double L,double U,double rel_error,double& val_R);

#endif