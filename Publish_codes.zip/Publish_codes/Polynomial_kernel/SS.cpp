#include "SS.h"

inline double power(double x,int index)
{
	double value=1;
	for(int i=0;i<index;i++)
		value=value*x;

	return value;
}

inline double kernel_Compute(double*q,double*p,int dim,SVM_stat& stat)
{
	double ip=0;
	double kernel_Value;

	//Compute inner product
	for(int d=0;d<dim;d++)
		ip+=q[d]*p[d];

	kernel_Value=power(stat.gammaValue*ip+stat.r,(int)stat.degree);

	return kernel_Value;
}

void SS_iter(double*q,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat)
{
	double incr_Value=0;

	for(int i=0;i<stat.total_sv;i++)
		incr_Value=incr_Value+alphaArray[i]*kernel_Compute(q,dataMatrix[i],dim,stat);

	#ifdef EXACT_VALUE_STATS
		stat.exactValueVector.push_back(incr_Value);
	#endif

	if(incr_Value>stat.rho)
		stat.class_resultVector.push_back(1);
	else
		stat.class_resultVector.push_back(-1);
}