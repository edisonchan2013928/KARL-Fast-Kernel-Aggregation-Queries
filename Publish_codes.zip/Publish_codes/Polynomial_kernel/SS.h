#ifndef SS_H
#define SS_H

#include "init_KC.h"
#include "my_svm.h"
#include "ip_bound.h"

void SS_iter(double*q,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat);

#endif