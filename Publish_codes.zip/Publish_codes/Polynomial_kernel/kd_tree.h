#ifndef KD_TREE_H
#define KD_TREE_H

#include "Tree.h"

class kdNode : public Node
{
public:
	double**boundary; //boundary

	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);

	void update_Aug(Node*node,Tree*t){}

	kdNode*createNode();
};

class kdLinearAugNode : public kdNode
{
public:
	double*a_G;
	double S_G;

	//facilitates online (sharing) computation
	//double gamma_sum;
	double temp_ell;
	double temp_u;

	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);

	void update_linearAugInfo(kdLinearAugNode*node,Tree*t);

	void update_Aug(Node*node,Tree*t);
	kdLinearAugNode*createNode();
};

class kdLinearAugNode_c : public kdLinearAugNode
{
public:
	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);
	kdLinearAugNode_c*createNode();
};

class kdTree : public Tree
{
public:
	//Member functions
	kdTree(int dim,double**dataMatrix,double*alphaArray,int leafCapacity,SVM_stat& stat);

	void getNode_Boundary(kdNode*node);
	double obtain_SplitValue(kdNode*node,int split_Dim);
	void KD_Tree_Recur(kdNode*node,int split_Dim);
	void build_kdTree(SVM_stat& stat);
	void initTree_alpha(kdNode*node);

	void updateAugment(kdNode*node);
};

#endif