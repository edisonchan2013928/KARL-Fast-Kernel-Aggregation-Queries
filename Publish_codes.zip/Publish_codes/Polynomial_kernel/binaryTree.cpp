#include "binaryTree.h"

struct order_Entry
{
	int id;
	double dist;
	double norm;
	double ip;
};

bool compare_order_Entry(const order_Entry& o_Entry1,const order_Entry& o_Entry2)
{
	return o_Entry1.dist < o_Entry2.dist; 
}

bool compare_order_Entry_decr(const order_Entry& o_Entry1,const order_Entry& o_Entry2)
{
	return o_Entry1.dist > o_Entry2.dist;
}

//binaryNode
double binaryNode::LB(double*q,int dim,SVM_stat& stat)
{
	return 0;
}

double binaryNode::UB(double*q,int dim,SVM_stat& stat)
{
	return 0;
}

binaryNode*binaryNode::createNode()
{
	return new binaryNode();
}

void binaryNode::update_Aug(Node*node,Tree*t)
{
	//no code
}

void binaryNode::update_Aug(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat)
{
	int id;

	//initialization 
	sum_alpha=0;
	a_G=new double[dim];

	for(int d=0;d<dim;d++)
		a_G[d]=0;

	//(1)update sum_alpha //(2)update a_G
	for(int i=0;i<(int)idList.size();i++)
	{
		id=idList[i];
		sum_alpha+=alphaArray[id]; //(1)
		for(int d=0;d<dim;d++)
			a_G[d]+=alphaArray[id]*dataMatrix[id][d];
	}
}

void binaryNode::GPA(binaryNode*node1,binaryNode*node2,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat)
{
	//no code
}

void binaryNode::initNode(int dim)
{
	//(1)init sum_alpha //(2)init a_G
	sum_alpha=0; //(1)
	a_G=new double[dim];
	for(int d=0;d<dim;d++)
		a_G[d]=0; //(2)
}

void binaryNode::Aug_Incr(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat,int id/*,double& update_Radius*/)
{
	//(1)update sum_alpha //(2)update a_G
	sum_alpha+=alphaArray[id]; //(1)
	for(int d=0;d<dim;d++)
		a_G[d]+=alphaArray[id]*dataMatrix[id][d]; //(2)
}

void binaryNode::Aug_Decr(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat,int id)
{
	//(1)update sum_alpha //(2)update a_G
	sum_alpha-=alphaArray[id]; //(1)
	for(int d=0;d<dim;d++)
		a_G[d]-=alphaArray[id]*dataMatrix[id][d]; //(2)
}

void binaryNode::assign(binaryNode*bNode_delta,int dim)
{
	//(1)assign sum_alpha //(2)assign a_G
	sum_alpha=bNode_delta->sum_alpha; //(1)

	for(int d=0;d<dim;d++)
		a_G[d]=bNode_delta->a_G[d]; //(2)
}

//ballNode
double ballNode::LB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;
	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_square,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_cubic;

	ell=ell_ip_MBR(q,boundary,dim);
	u=u_ip_MBR(q,boundary,dim);

	this->temp_ell=ell;
	this->temp_u=u;

	//Case 1: gamma*ell+k>=0
	if(stat.gammaValue*ell+stat.r>=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}
	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
	{
		gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
		gamma_u_plus_r=stat.gammaValue*u+stat.r;

		gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
		gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

		m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
		c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	}

	//Case 3: gamma*ell+k<0<gamma*u+k
	gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
	gamma_ell_plus_r_square=gamma_ell_plus_r*gamma_ell_plus_r;
	gamma_ell_plus_r_cubic=gamma_ell_plus_r_square*gamma_ell_plus_r;

	return 0.75*stat.gammaValue*gamma_ell_plus_r_square*ip_value(q,a_G,dim)
		+(0.75*gamma_ell_plus_r_square*stat.r+0.25*gamma_ell_plus_r_cubic)*sum_alpha;
}

double ballNode::UB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;

	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_square,gamma_u_plus_r_cubic;

	ell=this->temp_ell;
	u=this->temp_u;

	//Case 1: gamma*ell+k>=0
	if(stat.gammaValue*ell+stat.r>=0)
	{
		gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
		gamma_u_plus_r=stat.gammaValue*u+stat.r;

		gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
		gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

		m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
		c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	}
	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}

	//Case 3: gamma*ell+k<0<gamma*u+k
	gamma_u_plus_r=stat.gammaValue*u+stat.r;
	gamma_u_plus_r_square=gamma_u_plus_r*gamma_u_plus_r;
	gamma_u_plus_r_cubic=gamma_u_plus_r_square*gamma_u_plus_r;

	return 0.75*stat.gammaValue*gamma_u_plus_r_square*ip_value(q,a_G,dim)
		+(0.75*gamma_u_plus_r_square*stat.r+0.25*gamma_u_plus_r_cubic)*sum_alpha;
}

void ballNode::update_Aug(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat)
{
	binaryNode::update_Aug(dataMatrix,alphaArray,dim,stat);
	updateBoundary(dataMatrix,stat,dim);
}

void find_furthest(double*pivot,vector<int>& idList,double**dataMatrix,double*alphaArray,int dim,int& id1,int& id2)
{
	double max_dist=-inf;
	double cur_dist;
	int cur_id;

	for(int i=0;i<(int)idList.size();i++)
	{
		cur_id=idList[i];
		cur_dist=euclid_dist(pivot,dataMatrix[cur_id],dim);

		if(cur_dist>max_dist)
		{
			max_dist=cur_dist;
			id1=cur_id;
		}
	}

	max_dist=-inf;
	for(int i=0;i<(int)idList.size();i++)
	{
		cur_id=idList[i];
		if(cur_id==id1)
			continue;

		cur_dist=euclid_dist(dataMatrix[id1],dataMatrix[cur_id],dim);

		if(cur_dist>max_dist)
		{
			max_dist=cur_dist;
			id2=cur_id;
		}
	}
}

void balance_saparation_basic(double**dataMatrix,int dim,int id1,int id2,vector<order_Entry>& o_EntryVector,binaryNode*node)
{
	order_Entry o_Entry;
	vector<order_Entry> o_EntryVector1;
	vector<order_Entry> o_EntryVector2;
	double euclid_1;
	double euclid_2;

	for(int i=0;i<(int)node->idList.size();i++)
	{
		o_Entry.id=node->idList[i];

		if((int)o_EntryVector1.size()>(int)(node->idList.size()/2.0))
		{
			o_Entry.dist=euclid_dist(dataMatrix[id2],dataMatrix[node->idList[i]],dim);
			o_EntryVector2.push_back(o_Entry);
			continue;
		}

		if((int)o_EntryVector2.size()>(int)(node->idList.size()/2.0))
		{
			o_Entry.dist=euclid_dist(dataMatrix[id1],dataMatrix[node->idList[i]],dim);
			o_EntryVector1.push_back(o_Entry);
			continue;
		}

		euclid_1=euclid_dist(dataMatrix[id1],dataMatrix[node->idList[i]],dim);
		euclid_2=euclid_dist(dataMatrix[id2],dataMatrix[node->idList[i]],dim);
		if(euclid_1<euclid_2)
		{
			o_Entry.dist=euclid_1;
			o_EntryVector1.push_back(o_Entry);
		}
		else
		{
			o_Entry.dist=euclid_2;
			o_EntryVector2.push_back(o_Entry);
		}
	}

	sort(o_EntryVector1.begin(),o_EntryVector1.end(),compare_order_Entry);
	sort(o_EntryVector2.begin(),o_EntryVector2.end(),compare_order_Entry_decr);

	o_EntryVector.insert(o_EntryVector.end(),o_EntryVector1.begin(),o_EntryVector1.end());
	o_EntryVector.insert(o_EntryVector.end(),o_EntryVector2.begin(),o_EntryVector2.end());
	o_EntryVector1.clear();
	o_EntryVector2.clear();
}

void half_division(vector<order_Entry>& o_EntryVector,binaryNode*node1,binaryNode*node2,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat)
{
	int halfSize=(int)ceil((double)o_EntryVector.size()/2.0);
	for(int i=0;i<(int)o_EntryVector.size();i++)
	{
		if(i<halfSize)
		{
			node1->idList.push_back(o_EntryVector[i].id);
			node1->Aug_Incr(dataMatrix,alphaArray,dim,stat,o_EntryVector[i].id);
		}
		else
		{
			node2->idList.push_back(o_EntryVector[i].id);
			node2->Aug_Incr(dataMatrix,alphaArray,dim,stat,o_EntryVector[i].id);
		}
	}

	o_EntryVector.clear();
}

void ballNode::GPA(binaryNode*node1,binaryNode*node2,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat)
{
	static int isRoot=1;
	int id1,id2;
	static double*center;
	static int counter=0;

	if(counter==0)
	{
		center=new double[dim];
		counter++;
	}

	for(int d=0;d<dim;d++)
		center[d]=a_G[d]/sum_alpha;

	vector<order_Entry> o_EntryVector;

	if(isRoot==1)
		isRoot=0;
	else
		updateBoundary(dataMatrix,stat,dim);

	find_furthest(center,this->idList,dataMatrix,alphaArray,dim,id1,id2);
	balance_saparation_basic(dataMatrix,dim,id1,id2,o_EntryVector,this);

	half_division(o_EntryVector,node1,node2,dataMatrix,alphaArray,dim,stat);
}

void ballNode::updateBoundary(double**dataMatrix,SVM_stat& stat,int dim)
{
	int id;

	boundary=new double*[dim];
	for(int d=0;d<dim;d++)
		boundary[d]=new double[2];

	//initialization of boundary
	for(int d=0;d<dim;d++)
	{
		boundary[d][0]=inf;
		boundary[d][1]=-inf;
	}

	for(int i=0;i<(int)idList.size();i++)
	{
		id=idList[i];
		for(int d=0;d<dim;d++)
		{
			if(dataMatrix[id][d]<boundary[d][0])
				boundary[d][0]=dataMatrix[id][d];
			if(dataMatrix[id][d]>boundary[d][1])
				boundary[d][1]=dataMatrix[id][d];
		}
	}
}

ballNode*ballNode::createNode()
{
	return new ballNode();
}

//ballNode_c
double ballNode_c::LB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;
	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_cubic;

	ell=ell_ip_MBR(q,boundary,dim);
	u=u_ip_MBR(q,boundary,dim);

	this->temp_ell=ell;
	this->temp_u=u;

	//Case 1: gamma*ell+k>=0
	if(stat.gammaValue*ell+stat.r>=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}
	
	gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
	gamma_u_plus_r=stat.gammaValue*u+stat.r;

	gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
	gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

	m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
	c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	
	//Case 3: gamma*ell+k<0<gamma*u+k
	double D_down;
	double sqrt_Value;
	sqrt_Value=sqrt(m/3.0);
	D_down=m*sqrt_Value+c-pow_term(sqrt_Value,3);
	return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c-D_down)*sum_alpha);
}

double ballNode_c::UB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;

	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_cubic;

	ell=this->temp_ell;
	u=this->temp_u;

	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}

	//Case 1: gamma*ell+k>=0
	gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
	gamma_u_plus_r=stat.gammaValue*u+stat.r;

	gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
	gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

	m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
	c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

	if(stat.gammaValue*ell+stat.r>=0)
		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	
	//Case 3: gamma*ell+k<0<gamma*u+k
	double D_up;
	double sqrt_Value;
	sqrt_Value=sqrt(m/3.0);
	D_up=m*sqrt_Value-c-pow_term(sqrt_Value,3);
	return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c+D_up)*sum_alpha);
}

ballNode_c*ballNode_c::createNode()
{
	return new ballNode_c();
}

//ballNode_SOTA
double ballNode_SOTA::LB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double L;
	ell=ell_ip_MBR(q,boundary,dim);

	L=sum_alpha*pow_term(stat.gammaValue*ell+stat.r,3);

	return L;
}

double ballNode_SOTA::UB(double*q,int dim,SVM_stat& stat)
{
	double u;
	double U;
	u=u_ip_MBR(q,boundary,dim);

	U=sum_alpha*pow_term(stat.gammaValue*u+stat.r,3);

	return U;
}

ballNode_SOTA*ballNode_SOTA::createNode()
{
	return new ballNode_SOTA();
}

//binaryTree
void binaryTree::build_BinaryTreeRecur(binaryNode*node)
{
	if((int)node->idList.size()>leafCapacity)
	{
		binaryNode*node1=node->createNode();
		binaryNode*node2=node->createNode();

		node1->initNode(dim);
		node2->initNode(dim);
		
		node->GPA(node1,node2,dataMatrix,alphaArray,dim,stat);

		build_BinaryTreeRecur(node1);
		build_BinaryTreeRecur(node2);

		node->childVector.push_back(node1);
		node->childVector.push_back(node2);
	}
	else //leafNode
	{
		node->update_Aug(dataMatrix,alphaArray,dim,stat);
		//with SVM model
		node->initModel_inMemory(dataMatrix,alphaArray,dim,stat);
		node->createModel_inMemory(dataMatrix,alphaArray,dim,stat);
	}
}

void binaryTree::build_BinaryTree()
{
	binaryNode*& bNode=(binaryNode*&) rootNode;
	for(int i=0;i<stat.total_sv;i++)
		bNode->idList.push_back(i);

	bNode->update_Aug(dataMatrix,alphaArray,dim,stat);

	build_BinaryTreeRecur((binaryNode*)rootNode);
}

binaryTree::binaryTree(int dim,double**dataMatrix,double*alphaArray,int leafCapacity,SVM_stat& stat)
{
	this->dim=dim;
	this->dataMatrix=dataMatrix;
	this->alphaArray=alphaArray;
	this->leafCapacity=leafCapacity;
	this->stat=stat;
}