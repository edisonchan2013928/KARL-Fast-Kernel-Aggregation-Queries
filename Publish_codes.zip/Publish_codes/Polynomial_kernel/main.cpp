#include "GBF_KC.h"

int main(int argc,char**argv)
{
	int dim=atoi(argv[1]);
	int qNum=atoi(argv[2]);
	char*querysetFileName=argv[3];
	char*datasetFileName=argv[4];
	char*classResultName=argv[5];
	int method=atoi(argv[6]);
	int leafCapacity=atoi(argv[7]);

	/*int dim=9;
	int qNum=14500;
	char*querysetFileName=(char*)"shuttle_q_scale.dat";
	char*datasetFileName=(char*)"shuttle_model_default";
	char*classResultName=(char*)"test";
	int method=6;
	int leafCapacity=20;*/

	int n;
	double**queryMatrix;
	double*queryOutputArray;
	double**dataMatrix;
	double*alphaArray;

	//Used by libSVM method
	SVM_stat stat;
	stat.pruneCount=0;

	extract_FeatureVector(querysetFileName,qNum,dim,queryMatrix,queryOutputArray,false,stat);
	extract_FeatureVector(datasetFileName,n,dim,dataMatrix,alphaArray,true,stat);

	KC_Algorithm(queryMatrix,dataMatrix,alphaArray,qNum,dim,leafCapacity,method,stat);

	outputResultFile(classResultName,stat);
}