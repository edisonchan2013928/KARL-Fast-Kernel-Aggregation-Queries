#include "GBF_KC.h"

inline void clearHeap(PQ& pq)
{
	int heapSize=(int)pq.size();
	for(int h=0;h<heapSize;h++)
		pq.pop();
}

void GBF_iter(double*q,svm_node*svm_q,Tree& tree,int dim,SVM_stat& stat)
{
	static PQ pq;
	pqNode pq_entry;
	Node*curNode;
	double L,U;
	double f_cur;

	Node*rootNode=tree.rootNode;

	#ifdef PRUNE_STATS
		stat.numBound+=2.0;
	#endif

	L=rootNode->LB(q,dim,stat);
	U=rootNode->UB(q,dim,stat);

	pq_entry.node=rootNode;
	pq_entry.node_L=L;
	pq_entry.node_U=U;
	pq_entry.discrepancy=U-L;

	pq.push(pq_entry);

	while(pq.size()!=0)
	{
		if(L>=stat.rho)
		{
			stat.class_resultVector.push_back(1);
			stat.pruneCount++;
			clearHeap(pq);

			return;
		}
		if(U<stat.rho)
		{
			stat.class_resultVector.push_back(-1);
			stat.pruneCount++;
			clearHeap(pq);

			return;
		}

		pq_entry=pq.top();
		pq.pop();

		L=L-pq_entry.node_L;
		U=U-pq_entry.node_U;

		curNode=pq_entry.node;

		//leaf Node
		if((int)curNode->idList.size()<=tree.leafCapacity)
		{
			#ifdef PRUNE_STATS
				stat.numExact+=(double)curNode->idList.size();
			#endif

			f_cur=callSVM_Refine(svm_q,curNode->model,0,curNode->idList.size());

			L=L+f_cur;
			U=U+f_cur;

			continue;
		}

		//Non-Leaf Node
		for(int c=0;c<(int)curNode->childVector.size();c++)
		{
			#ifdef PRUNE_STATS
				stat.numBound+=2.0;
			#endif

			pq_entry.node_L=curNode->childVector[c]->LB(q,dim,stat);
			pq_entry.node_U=curNode->childVector[c]->UB(q,dim,stat);
			pq_entry.discrepancy=pq_entry.node_U-pq_entry.node_L;
			pq_entry.node=curNode->childVector[c];

			L=L+pq_entry.node_L;
			U=U+pq_entry.node_U;

			pq.push(pq_entry);
		}
	}

	if(L>=stat.rho)
	{
		stat.class_resultVector.push_back(1);
		clearHeap(pq);
		return;
	}
	if(U<stat.rho)
	{
		stat.class_resultVector.push_back(-1);
		clearHeap(pq);
		return;
	}
}

void KC_Algorithm(double**queryMatrix,double**dataMatrix,double*alphaArray,int qNum,int dim,int leafCapacity,int method,SVM_stat& stat)
{
	#ifndef C_PLUSPLUS11_CLOCK
		clock_t start_s;
		clock_t end_s;
	#endif

	double online_Time;

	kdTree kd_Tree(dim,dataMatrix,alphaArray,leafCapacity,stat);
	binaryTree binary_Tree(dim,dataMatrix,alphaArray,leafCapacity,stat);

	if(method==1)//tKDC kd-tree + LB_MBR and UB_MBR
		kd_Tree.rootNode=new kdNode();
	if(method==2)
		kd_Tree.rootNode=new kdLinearAugNode();
	if(method==3)
		kd_Tree.rootNode=new kdLinearAugNode_c();
	if(method==4)
		binary_Tree.rootNode=new ballNode_SOTA();
	if(method==5)
		binary_Tree.rootNode=new ballNode();
	if(method==6)
		binary_Tree.rootNode=new ballNode_c();

	//Used in LibSVM linear scan method
	svm_node**svm_qMatrix;
	svm_node*x_space;
	svm_model*model;
	convert_2D_qMatrix_to_SVMFormat(queryMatrix,svm_qMatrix,dim,qNum);

	//It is not used if LibSVM is not used
	if(method!=0)
		convert_2D_qMatrix_to_SVMFormat(queryMatrix,svm_qMatrix,dim,qNum);

	//preprocessing for the methods which require LibSVM
	if(method==7)
	{
		init_model_inMemory(dataMatrix,dim,stat,model,x_space);
		createModel_inMemory(dataMatrix,alphaArray,dim,stat,model,x_space);
	}

	//build tree Preprocessing + create augment tree
	if(method>=1 && method<=3)
	{
		kd_Tree.build_kdTree(stat);
		kd_Tree.updateAugment((kdNode*)kd_Tree.rootNode);
	}

	if(method>=4 && method<=6)
		binary_Tree.build_BinaryTree();

	//method=0 Linear Scan
	//method=1 kd-tree (MBR-based bound functions)
	//method=2 kd-tree (Our bound functions version 1)
	//method=3 kd-tree (Our bound functions version 2)
	//method=4 ball-tree (SOTA,MBR-based bound function) 
	//method=5 ball-tree (Our bound functions version 1)
	//method=6 ball-tree (Our bound functions version 2)
	//method=7 LibSVM
	//method=8 LibSVM_{B+}
	#ifdef C_PLUSPLUS11_CLOCK
		auto start_s=chrono::high_resolution_clock::now();
	#else
		start_s=clock();
	#endif

	for(int q=0;q<qNum;q++)
	{
		//Online One-Time processing
		switch (method)
		{
			case 0:
				SS_iter(queryMatrix[q],dataMatrix,alphaArray,dim,stat);
				break;
			case 1:
			case 2:
			case 3:
				//if(q==14)
				//	cout<<"HERE:"<<endl;
				GBF_iter(queryMatrix[q],svm_qMatrix[q],kd_Tree,dim,stat);
				break;
			case 4:
			case 5:
			case 6:
				GBF_iter(queryMatrix[q],svm_qMatrix[q],binary_Tree,dim,stat);
				break;
			case 7:
				stat.class_resultVector.push_back((int)svm_predict(model,svm_qMatrix[q]));
				break;
		}
	}

	#ifdef C_PLUSPLUS11_CLOCK
		auto end_s=chrono::high_resolution_clock::now();
		online_Time=(chrono::duration_cast<chrono::nanoseconds>(end_s-start_s).count())/1000000000.0;
	#else
		end_s=clock();
		online_Time=((double)(end_s-start_s))/CLOCKS_PER_SEC;
	#endif

	cout<<"Method "<<method<<": "<<((double)qNum/online_Time)<<" Queries/sec"<<endl;
	//cout<<"pruning ratio: "<<((double)stat.pruneCount)/((double)qNum)<<endl;
}