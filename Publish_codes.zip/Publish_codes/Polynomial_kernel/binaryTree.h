#ifndef BINARYTREE_H
#define BINARYTREE_H

#include "Tree.h"

class binaryNode : public Node
{
public:
	virtual ~binaryNode(){}

	double*a_G;

	//facilitates online (sharing) computation
	double temp_ell;
	double temp_u;

	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);

	//void update_linearAugInfo(binaryNode*node,Tree*t);
	void update_Aug(Node*node,Tree*t);
	virtual void update_Aug(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat);

	virtual void GPA(binaryNode*node1,binaryNode*node2,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat); //GPA

	void initNode(int dim);

	void Aug_Incr(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat,int id);
	void Aug_Decr(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat,int id);
	void assign(binaryNode*bNode_delta,int dim);

	binaryNode*createNode();
};

class ballNode : public binaryNode
{
public:
	double**boundary;
	//LB and UB functions declaration
	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);

	~ballNode(){}
	void update_Aug(double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat);
	//add GPA function
	void GPA(binaryNode*node1,binaryNode*node2,double**dataMatrix,double*alphaArray,int dim,SVM_stat& stat);
	void updateBoundary(double**dataMatrix,SVM_stat& stat,int dim);
	ballNode*createNode();
};

class ballNode_c : public ballNode
{
	//LB and UB functions declaration
	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);
	ballNode_c*createNode();
};

class ballNode_SOTA : public ballNode
{
public:
	~ballNode_SOTA(){}
	double LB(double*q,int dim,SVM_stat& stat);
	double UB(double*q,int dim,SVM_stat& stat);
	ballNode_SOTA*createNode();
};

class binaryTree : public Tree
{
public:
	binaryTree(int dim,double**dataMatrix,double*alphaArray,int leafCapacity,SVM_stat& stat);
	
	void build_BinaryTreeRecur(binaryNode*node);
	void build_BinaryTree();
};


#endif