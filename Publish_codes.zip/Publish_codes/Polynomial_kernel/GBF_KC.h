#ifndef GBF_KC_H
#define GBF_KC_H

#include "init_KC.h"
#include "SS.h"
#include "kd_tree.h"
#include "binaryTree.h"
#include "my_svm.h"

struct pqNode
{
	Node*node;
	double discrepancy;
	double node_L;
	double node_U;
};

//This is the maximum heap
struct comparePriority 
{
	bool operator()(pqNode& p1, pqNode& p2)
	{
		return p1.discrepancy<p2.discrepancy;
	}
};

typedef priority_queue<pqNode,vector<pqNode>,comparePriority> PQ;

//The tree can be any tree
void GBF_iter(double*q,svm_node*svm_q,Tree& tree,int dim,SVM_stat& stat);

void KC_Algorithm(double**queryMatrix,double**dataMatrix,double*alphaArray,int qNum,int dim,int leafCapacity,int method,SVM_stat& stat);

#endif