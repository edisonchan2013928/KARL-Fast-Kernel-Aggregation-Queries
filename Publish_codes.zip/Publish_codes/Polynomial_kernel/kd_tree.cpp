#include "kd_tree.h"

//kdNode
double kdNode::LB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double L;
	ell=ell_ip_MBR(q,boundary,dim);

	L=sum_alpha*pow_term(stat.gammaValue*ell+stat.r,3);

	return L;
}

double kdNode::UB(double*q,int dim,SVM_stat& stat)
{
	double u;
	double U;
	u=u_ip_MBR(q,boundary,dim);

	U=sum_alpha*pow_term(stat.gammaValue*u+stat.r,3);

	return U;
}

kdNode*kdNode::createNode()
{
	return new kdNode();
}

//kdLinearAugNode
double kdLinearAugNode::LB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;
	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_square,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_cubic;

	ell=ell_ip_MBR(q,boundary,dim);
	u=u_ip_MBR(q,boundary,dim);

	this->temp_ell=ell;
	this->temp_u=u;

	//Case 1: gamma*ell+k>=0
	if(stat.gammaValue*ell+stat.r>=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}
	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
	{
		gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
		gamma_u_plus_r=stat.gammaValue*u+stat.r;

		gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
		gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

		m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
		c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	}

	//Case 3: gamma*ell+k<0<gamma*u+k
	gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
	gamma_ell_plus_r_square=gamma_ell_plus_r*gamma_ell_plus_r;
	gamma_ell_plus_r_cubic=gamma_ell_plus_r_square*gamma_ell_plus_r;

	return 0.75*stat.gammaValue*gamma_ell_plus_r_square*ip_value(q,a_G,dim)
		+(0.75*gamma_ell_plus_r_square*stat.r+0.25*gamma_ell_plus_r_cubic)*sum_alpha;
}

double kdLinearAugNode::UB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;

	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_square,gamma_u_plus_r_cubic;

	ell=this->temp_ell;
	u=this->temp_u;

	//Case 1: gamma*ell+k>=0
	if(stat.gammaValue*ell+stat.r>=0)
	{
		gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
		gamma_u_plus_r=stat.gammaValue*u+stat.r;

		gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
		gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

		m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
		c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	}
	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}

	//Case 3: gamma*ell+k<0<gamma*u+k
	gamma_u_plus_r=stat.gammaValue*u+stat.r;
	gamma_u_plus_r_square=gamma_u_plus_r*gamma_u_plus_r;
	gamma_u_plus_r_cubic=gamma_u_plus_r_square*gamma_u_plus_r;

	return 0.75*stat.gammaValue*gamma_u_plus_r_square*ip_value(q,a_G,dim)
		+(0.75*gamma_u_plus_r_square*stat.r+0.25*gamma_u_plus_r_cubic)*sum_alpha;
}

void kdLinearAugNode::update_linearAugInfo(kdLinearAugNode*node,Tree*t)
{
	int id;
	//obtain vec a_G
	node->a_G=new double[t->dim];

	//We relate center and a_G in this way
	for(int d=0;d<t->dim;d++)
		node->a_G[d]=0;

	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		for(int d=0;d<t->dim;d++)
			node->a_G[d]+=t->alphaArray[id]*t->dataMatrix[id][d];
	}

	if((int)node->idList.size()<=t->leafCapacity) //this is the leaf node
		return;

	update_linearAugInfo((kdLinearAugNode*)node->childVector[0],t);
	update_linearAugInfo((kdLinearAugNode*)node->childVector[1],t);
}

void kdLinearAugNode::update_Aug(Node*node,Tree*t)
{
	this->update_linearAugInfo((kdLinearAugNode*)node,t);
}

kdLinearAugNode*kdLinearAugNode::createNode()
{
	return new kdLinearAugNode();
}

//kdLinearAugNode_c
double kdLinearAugNode_c::LB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;
	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_cubic;

	ell=ell_ip_MBR(q,boundary,dim);
	u=u_ip_MBR(q,boundary,dim);

	this->temp_ell=ell;
	this->temp_u=u;

	//Case 1: gamma*ell+k>=0
	if(stat.gammaValue*ell+stat.r>=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}
	
	gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
	gamma_u_plus_r=stat.gammaValue*u+stat.r;

	gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
	gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

	m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
	c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	
	//Case 3: gamma*ell+k<0<gamma*u+k
	double D_down;
	double sqrt_Value;
	sqrt_Value=sqrt(m/3.0);
	D_down=m*sqrt_Value+c-pow_term(sqrt_Value,3);
	return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c-D_down)*sum_alpha);
}

double kdLinearAugNode_c::UB(double*q,int dim,SVM_stat& stat)
{
	double ell;
	double u;
	double m,c;

	double numerator,denominator;
	double gamma_ell_plus_r,gamma_ell_plus_r_cubic;
	double gamma_u_plus_r,gamma_u_plus_r_cubic;

	ell=this->temp_ell;
	u=this->temp_u;

	//Case 2: gamma*u+k<=0
	if(stat.gammaValue*u+stat.r<=0)
	{
		numerator=pow_term(stat.gammaValue*ip_value(q,a_G,dim)+stat.r*sum_alpha,3);
		denominator=pow_term(sum_alpha,2);

		return (numerator/denominator);
	}

	//Case 1: gamma*ell+k>=0
	gamma_ell_plus_r=stat.gammaValue*ell+stat.r;
	gamma_u_plus_r=stat.gammaValue*u+stat.r;

	gamma_ell_plus_r_cubic=pow_term(gamma_ell_plus_r,3);
	gamma_u_plus_r_cubic=pow_term(gamma_u_plus_r,3);

	m=(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell));
	c=gamma_ell_plus_r_cubic-(gamma_u_plus_r_cubic-gamma_ell_plus_r_cubic)/(stat.gammaValue*(u-ell))*gamma_ell_plus_r;

	if(stat.gammaValue*ell+stat.r>=0)
		return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c)*sum_alpha);
	
	//Case 3: gamma*ell+k<0<gamma*u+k
	double D_up;
	double sqrt_Value;
	sqrt_Value=sqrt(m/3.0);
	D_up=m*sqrt_Value-c-pow_term(sqrt_Value,3);
	return (m*stat.gammaValue*ip_value(q,a_G,dim)+(m*stat.r+c+D_up)*sum_alpha);
}

kdLinearAugNode_c*kdLinearAugNode_c::createNode()
{
	return new kdLinearAugNode_c();
}

//kd-tree
kdTree::kdTree(int dim,double**dataMatrix,double*alphaArray,int leafCapacity,SVM_stat& stat)
{
	this->dim=dim;
	this->dataMatrix=dataMatrix;
	this->leafCapacity=leafCapacity;
	this->alphaArray=alphaArray;
	this->stat=stat;
}

void kdTree::getNode_Boundary(kdNode*node)
{
	int id;
	node->boundary=new double*[dim];
	for(int d=0;d<dim;d++)
		node->boundary[d]=new double[2];

	for(int d=0;d<dim;d++)
	{
		node->boundary[d][0]=inf;
		node->boundary[d][1]=-inf;
	}

	for(int d=0;d<dim;d++)
	{
		for(int i=0;i<(int)node->idList.size();i++)
		{
			id=node->idList[i];
			if(dataMatrix[id][d]<node->boundary[d][0])
				node->boundary[d][0]=dataMatrix[id][d];

			if(dataMatrix[id][d]>node->boundary[d][1])
				node->boundary[d][1]=dataMatrix[id][d];
		}
	}
}

double kdTree::obtain_SplitValue(kdNode*node,int split_Dim)
{
	vector<double> tempVector;
	int id;
	int middle_left,middle_right,middle;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		tempVector.push_back(dataMatrix[id][split_Dim]);
	}

	sort(tempVector.begin(),tempVector.end());

	if((int)tempVector.size()%2==0)//even number
	{
		middle_right=(int)tempVector.size()/2;
		middle_left=middle_right-1;

		return ((tempVector[middle_left]+tempVector[middle_right])/2.0);
	}
	else
	{
		middle=((int)tempVector.size()-1)/2;
		return tempVector[middle];
	}

	tempVector.clear();
}

void kdTree::KD_Tree_Recur(kdNode*node,int split_Dim)
{
	int id;
	int counter;
	//base case
	if((int)node->idList.size()<=leafCapacity)
	{
		node->initModel_inMemory(dataMatrix,alphaArray,dim,stat);
		node->createModel_inMemory(dataMatrix,alphaArray,dim,stat);
		return;
	}
	
	//added for testing
	//split_Dim=select_split_Dim(node);
	double splitValue=obtain_SplitValue(node,split_Dim); //code here

	//create two children
	kdNode*leftNode;
	kdNode*rightNode;

	leftNode=node->createNode();
	rightNode=node->createNode();

	counter=0;
	int halfSize=((int)node->idList.size())/2;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		if(dataMatrix[id][split_Dim]<=splitValue && counter<=halfSize)
		{
			leftNode->idList.push_back(id);
			counter++;
		}
		else
			rightNode->idList.push_back(id);
	}

	getNode_Boundary(leftNode);
	getNode_Boundary(rightNode);

	KD_Tree_Recur(leftNode,(split_Dim+1)%dim);
	KD_Tree_Recur(rightNode,(split_Dim+1)%dim);

	node->childVector.push_back(leftNode);
	node->childVector.push_back(rightNode);
}

void kdTree::build_kdTree(SVM_stat& stat)
{
	for(int i=0;i<stat.total_sv;i++)
		rootNode->idList.push_back(i);

	getNode_Boundary((kdNode*)rootNode);
	KD_Tree_Recur((kdNode*)rootNode,0);
	initTree_alpha((kdNode*)rootNode);
}

void kdTree::initTree_alpha(kdNode*node)
{
	double sum_alpha=0;
	int id;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		sum_alpha+=alphaArray[id];
	}
	node->sum_alpha=sum_alpha;

	if((int)node->idList.size()>leafCapacity)
	{
		initTree_alpha((kdNode*)node->childVector[0]);
		initTree_alpha((kdNode*)node->childVector[1]);
	}
}

void kdTree::updateAugment(kdNode*node)
{
	node->update_Aug(node,this);
}