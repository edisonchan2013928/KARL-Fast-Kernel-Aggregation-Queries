#include "file_convertion.h"

int main(int argc, char**argv)
{
	KDE_stat stat;
	char*KDE_queryfileName = argv[1];
	char*KARL_queryfileName = argv[2];
	char*KDE_datafileName = argv[3];
	char*KARL_datafileName = argv[4];
	stat.b = atof(argv[5]);
	stat.is_tau = atoi(argv[6]);

	if (stat.is_tau == true)
		stat.threshold = atof(argv[7]);

	KDE_to_KARL(KDE_datafileName, KARL_datafileName, stat, false);
	KDE_to_KARL(KDE_queryfileName, KARL_queryfileName, stat, true);
}