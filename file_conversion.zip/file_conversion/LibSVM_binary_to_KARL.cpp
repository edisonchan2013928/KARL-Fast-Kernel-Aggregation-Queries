#include "file_convertion.h"

int main(int argc, char**argv)
{
	SVM_stat stat;
	char*LibSVM_fileName = argv[1];
	char*KARL_fileName = argv[2];
	bool isQuery = (bool)atoi(argv[3]);
	
	stat.dim = atoi(argv[4]);
	if (isQuery == true)
		stat.n_q = atoi(argv[5]);

	//Example
	//char*LibSVM_fileName = (char*)"../../Dataset_Testing/OC_SVM/Sigmoid_kernel/NSLkdd_model_10";
	//char*KARL_fileName = (char*)"NSLkdd_our_model";
	//bool isQuery = false;

	//stat.dim = 41;
	//if (isQuery == true)
	//	stat.n_q = 30956;

	LibSVM_to_KARL(LibSVM_fileName, KARL_fileName, stat, isQuery);
}