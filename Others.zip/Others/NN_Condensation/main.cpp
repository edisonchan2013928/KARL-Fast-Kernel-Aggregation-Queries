#include "NN_Condensation.h"

int main(int argc,char**argv)
{
	/*int dim=atoi(argv[1]);
	char*datasetFileName=argv[2];
	char*outputFileName=argv[3];
	int n=atoi(argv[4]);*/

	int dim=54;
	char*datasetFileName=(char*)"covtype";
	char*outputFileName=(char*)"covtype_FCNN";
	int n=522911;

	double**dataMatrix;
	double*outputArray;
	SVM_stat stat;
	vector<int> S;

	extract_FeatureVector(datasetFileName,n,dim,dataMatrix,outputArray,false,stat);
	FCNN(dataMatrix,outputArray,n,dim,S);

	outSample_file(outputFileName,dataMatrix,outputArray,dim,S);
}