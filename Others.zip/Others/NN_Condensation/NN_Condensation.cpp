#include "NN_Condensation.h"

void findCentroid(double**dataMatrix,double*outputArray,int data_size,int dim,vector<int>& delta_S)
{
	double*center_c1=new double[dim];
	double*center_c2=new double[dim];
	double min_c1=inf;
	double min_c2=inf;
	int id1,id2;
	double dist;

	for(int d=0;d<dim;d++)
	{
		center_c1[d]=0;
		center_c2[d]=0;
	}

	for(int i=0;i<data_size;i++)
	{
		if(outputArray[i]>0)
		{
			for(int d=0;d<dim;d++)
				center_c1[d]+=dataMatrix[i][d];
		}
		else
		{
			for(int d=0;d<dim;d++)
				center_c2[d]+=dataMatrix[i][d];
		}
	}

	for(int i=0;i<data_size;i++)
	{
		if(outputArray[i]>0)
		{
			dist=euclid_dist(center_c1,dataMatrix[i],dim);
			if(dist<min_c1)
			{
				min_c1=dist;
				id1=i;
			}
		}
		else
		{
			dist=euclid_dist(center_c2,dataMatrix[i],dim);
			if(dist<min_c2)
			{
				min_c2=dist;
				id2=i;
			}
		}
	}

	delta_S.push_back(id1);
	delta_S.push_back(id2);
}

void set_exclusion(vector<int>& T,vector<int>& delta_S)
{
	for(int i=0;i<(int)delta_S.size();i++)
	{
		for(int j=0;j<(int)T.size();j++)
		{
			if(delta_S[i]==T[j])
			{
				T.erase(T.begin()+j);
				break;
			}
		}
	}
	//T.erase(T.begin()+delta_S[i]);
}

void set_Union(vector<int>& S,vector<int>& delta_S)
{
	bool inside_Set;
	for(int i=0;i<(int)delta_S.size();i++)
	{
		inside_Set=false;
		for(int j=0;j<(int)S.size();j++)
		{
			if(delta_S[i]==S[j])
			{
				inside_Set=true;
				break;
			}
		}

		if(inside_Set==false)
			S.push_back(delta_S[i]);
	}
}

inline void obtain_NN(int q,double**dataMatrix,int dim,vector<int>& delta_S,int*nearest)
{
	double euclid;
	double best_euclid;
	int p;
	for(int i=0;i<(int)delta_S.size();i++)
	{
		p=delta_S[i];
		euclid=euclid_dist(dataMatrix[q],dataMatrix[p],dim);

		if(nearest[q]==-1)
			nearest[q]=p;
		else
		{
			best_euclid=euclid_dist(dataMatrix[q],dataMatrix[nearest[q]],dim);
			if(best_euclid>euclid)
				nearest[q]=p;
		}
	}
}

inline void update_rep(int q,double**dataMatrix,double*outputArray,int dim,int*nearest,int*rep)
{
	double rep_euclid;
	double best_euclid;

	//l(q)=l(nearest[q])
	if(fabs(outputArray[q]-outputArray[nearest[q]])<epsilon)
		return;

	if(rep[nearest[q]]==-1)
		rep[nearest[q]]=q;
	else
	{
		best_euclid=euclid_dist(dataMatrix[nearest[q]],dataMatrix[q],dim);
		rep_euclid=euclid_dist(dataMatrix[nearest[q]],dataMatrix[rep[nearest[q]]],dim);

		if(best_euclid<rep_euclid)
			rep[nearest[q]]=q;
	}
}

void FCNN(double**dataMatrix,double*outputArray,int data_size,int dim,vector<int>& S)
{
	//initialization of the variables
	int*nearest=new int[data_size];
	int*rep=new int[data_size];
	vector<int> delta_S;
	vector<int> T;
	int iteration=0;

	for(int i=0;i<data_size;i++)
	{
		T.push_back(i);
		nearest[i]=-1; //undefined if we set it to 1
		rep[i]=-1; //undefined if we set it to 1
	}

	findCentroid(dataMatrix,outputArray,data_size,dim,delta_S);

	while((int)delta_S.size()>0 && iteration<10000)
	{
		iteration++;
		cout<<iteration<<endl;
		//S <- S union delta_S
		//set_Union(S,delta_S);
		for(int i=0;i<(int)delta_S.size();i++)
			S.push_back(delta_S[i]);

		for(int i=0;i<(int)S.size();i++)
			rep[S[i]]=-1;

		//obtain T \not S (T becomes T\not S)
		set_exclusion(T,S);

		for(int q_index=0;q_index<(int)T.size();q_index++)
		{
			obtain_NN(T[q_index],dataMatrix,dim,delta_S,nearest);
			//update rep
			update_rep(T[q_index],dataMatrix,outputArray,dim,nearest,rep);
		}

		delta_S.clear();
		for(int i=0;i<(int)S.size();i++)
		{
			if(rep[S[i]]!=-1)
				delta_S.push_back(rep[S[i]]);
		}
	}

	if(iteration==10000)
		cout<<"number of iterations exceeds the maximum"<<endl;
}

void outSample_file(char*outputFileName,double**dataMatrix,double*outputArray,int dim,vector<int>& S)
{
	fstream outputFile;
	outputFile.open(outputFileName,ios::in | ios::out | ios::trunc);
	if(outputFile.is_open()==false)
	{
		cout<<"Cannot open subsample file!";
		exit(1);
	}

	for(int i=0;i<(int)S.size();i++)
	{
		outputFile<<outputArray[S[i]]<<" ";
		for(int d=0;d<dim;d++)
		{
			if(fabs(dataMatrix[S[i]][d])>epsilon)
				outputFile<<(d+1)<<":"<<dataMatrix[S[i]][d]<<" ";
		}
		outputFile<<endl;
	}

	outputFile.close();
}