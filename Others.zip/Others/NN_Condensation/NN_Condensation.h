#ifndef NN_CONDENSATION_H
#define NN_CONDENSATION_H

#include "init_KC.h"
#include "Euclid_Bound.h"

void FCNN(double**dataMatrix,double*outputArray,int data_size,int dim,vector<int>& S);

void outSample_file(char*outputFileName,double**dataMatrix,double*outputArray,int dim,vector<int>& S);

#endif