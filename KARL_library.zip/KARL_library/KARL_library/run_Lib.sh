g++ -c Euclid_Bound.cpp -w -o Euclid_Bound.o -std=c++11
g++ -c GBF.cpp -w -o GBF.o -std=c++11
g++ -c init_KARL.cpp -w -o init_KARL.o -std=c++11
g++ -c ip_bound.cpp -w -o ip_bound.o -std=c++11
g++ -c kd_tree.cpp -w -o kd_tree.o -std=c++11
g++ -c ball_tree.cpp -w -o ball_tree.o -std=c++11
g++ -c slope_intercept.cpp -w -o slope_intercept.o -std=c++11
g++ -c SS.cpp -w -o SS.o -std=c++11
g++ -c Tree.cpp -w -o Tree.o -std=c++11
g++ -c Validation.cpp -w -o Validation.o -std=c++11

g++ KARL.cpp -O3 -o KARL Euclid_Bound.o GBF.o init_KARL.o ip_bound.o kd_tree.o ball_tree.o slope_intercept.o SS.o Tree.o Validation.o -std=c++11

#argv[1]: querysetFileName (char*)
#argv[2]: datasetFileName (char*)
#argv[3]: resultFileName (char*)
#argv[4]: method (int)
#argv[5]: leafCapacity (int)
#argv[6]: epsilon (double)

#Running Example
#Gaussian Kernel
#One_Class SVM Classification
#nsl-kdd
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_model ./Result/nsl_kdd_rbf_M0 0 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_model ./Result/nsl_kdd_rbf_M1 1 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_model ./Result/nsl_kdd_rbf_M2 2 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_model ./Result/nsl_kdd_rbf_M3 3 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/nsl_kdd/nsl_kdd_rbf_our_model ./Result/nsl_kdd_rbf_M4 4 80

#KDDCup
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_model ./Result/KDDCup_rbf_M0 0 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_model ./Result/KDDCup_rbf_M1 1 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_model ./Result/KDDCup_rbf_M2 2 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_model ./Result/KDDCup_rbf_M3 3 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/KDDCup/KDDCup_rbf_our_model ./Result/KDDCup_rbf_M4 4 80

#covtype
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_model ./Result/covtype_rbf_M0 0 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_model ./Result/covtype_rbf_M1 1 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_model ./Result/covtype_rbf_M2 2 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_model ./Result/covtype_rbf_M3 3 80
./KARL ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_test ../Datasets/OCSVM_classification/Gaussian_kernel/covtype/covtype_rbf_our_model ./Result/covtype_rbf_M4 4 80
