Readme file for KARL library:

This library supports different types of machine learning models, including density estimation, regression and classification models.
Based on the Representation theorem [1], the online predictive function of these models exhibits this form:
F_P(q)=\sum_{p_i\in P} w_i K(q,p_i)

In the above models, they either need to perform the following two types of queries/operations in the online phase, namely:
1: approximate kernel aggregation query (epsilon-KAQ) e.g., kernel density estimation and regression models
2: thresholded kernel aggregation query (tau-KAQ) e.g., kernel density classification, 1-class/ 2-class SVM and some regression models (logistic regression)

We have the format requirement for using this library. First, we need to have two files:
1: Query file (stores all the feature vectors in which you want to predict.)
2: Model file (stores all the feature vectors which are the output of the training model.)

The format of query file is:
===============================================
n_q dim
dimension_values
...
dimension_values
===============================================

n_q: number of queries (integer)
dim: number of dimensions (integer)
dimension_values: each row represents one feature vector

For example, this is the valid format of query file
===============================================
3 2
12 6
11 3
14 4
===============================================


The format of model file is:
===============================================
n_d dim kernel_type gamma [degree beta] is_tau [tau_value]
dimension_values
...
dimension_values
===============================================

n_d: number of feature vectors in the dataset (integer)
dim: number of dimensions (integer)
kernel_type: different types of kernels (string)
	RBF/ Gaussian kernel: rbf
	Polynomial kernel: poly
	Sigmoid kernel: sigmoid
gamma: gamma value (double)
degree: The degree of polynomial kernel (double) [Need to specify this variable if kernel_type = poly]
beta: The constant coefficient of polynomial and sigmoid kernels (double) [Need to specify this variable if kernel_type = poly or sigmoid]
is_tau: is_tau=0 means the epsilon-KAQ and is_tau=1 means the tau-KAQ (boolean)
tau: threshold value (double)[Need to specify this variable if is_tau = 1]
dimension_values: each row represents one feature vector

For example, this is the valid format of model file
===============================================
4 2 rbf 0.2 0
7 5
6 2
7 7
6 3
===============================================

If you use this library, you need to follow the following two steps:
===============================================
1: First, you need to convert the query set/ dataset into the above format.
2: Second, you need to specify the parameters in the command line.

argv[1]: querysetFileName (string)
argv[2]: datasetFileName (string)
argv[3]: resultFileName (string)
argv[4]: method (integer)
argv[5]: leafCapacity (integer)
argv[6]: epsilon (double) [if the model file belongs to tau-KAQ, you do not need to specify this parameter argv[6]]

The compilation and some example running scripts have been added into Github with file name "run_Lib.sh"
===============================================

Our Library currently includes 5 methods.
0: SCAN
1: KD-tree (SOTA)
2: KD-tree (KARL)
3: Ball-tree (SOTA)
4: Ball-tree (KARL)

For step 1, we have included some file conversion codes for you to change from other models to our file format, e.g., LibSVM to our format.