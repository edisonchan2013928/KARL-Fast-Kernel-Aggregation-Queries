#pragma once
#ifndef SS_H
#define SS_H

#include "init_KARL.h"
#include "Tree.h"
#include "Euclid_Bound.h"

double refine(double*q, Node*curNode, model& our_model);
void SS_iter(int q_id, model& our_model);

#endif