#include "SS.h"

double refine(double*q, Node*curNode, model& our_model)
{
	double incr_Value = 0;
	double sq_Value;
	double ip;
	int id;
	int node_size = (int)curNode->idList.size();

	for (int i = 0; i < node_size; i++)
	{
		id = curNode->idList[i];

		if (our_model.kernel_type == "rbf")
		{
			sq_Value = euclid_dist_sq(q, our_model.dataMatrix[id], our_model.dim);
			incr_Value += our_model.weight_oriVector[id] * exp(-our_model.gamma*sq_Value);
		}
		else
		{
			ip = ip_value(q, our_model.dataMatrix[id], our_model.dim);
			if (our_model.kernel_type == "poly")
				incr_Value += our_model.weight_oriVector[id] * pow_term(our_model.gamma*ip + our_model.beta, (int)our_model.deg);
			if (our_model.kernel_type == "sig")
				incr_Value += our_model.weight_oriVector[id] * tanh(our_model.gamma*ip + our_model.beta);
		}
	}

	return incr_Value;
}

void SS_iter(int q_id, model& our_model)
{
	double incr_Value = 0;
	double sq_Value;
	double ip;

	for (int i = 0; i < our_model.n_d; i++)
	{
		if (our_model.kernel_type == "rbf")
		{
			sq_Value = euclid_dist_sq(our_model.queryMatrix[q_id], our_model.dataMatrix[i], our_model.dim);
			incr_Value += our_model.weight_oriVector[i] * exp(-our_model.gamma*sq_Value);
		}
		else
		{
			ip = ip_value(our_model.queryMatrix[q_id], our_model.dataMatrix[i], our_model.dim);
			if (our_model.kernel_type == "poly")
				incr_Value += our_model.weight_oriVector[i] * pow_term(our_model.gamma*ip + our_model.beta, (int)our_model.deg);
			if (our_model.kernel_type == "sig")
				incr_Value += our_model.weight_oriVector[i] * tanh(our_model.gamma*ip + our_model.beta);
		}
	}

	if (our_model.is_tau == 0)
		our_model.resultVector[q_id] = incr_Value;
	else
	{
		if (incr_Value > our_model.tau)
			our_model.resultVector[q_id] = 1;
		else
			our_model.resultVector[q_id] = -1;
	}
}